#include <cstdlib>
#include "codegenqt.h"

using namespace qXsd2Code;

void CodeGenQT::functionsFile()
{
	// open the header file
	QString name = nameSpaceName() + "_" + "Functions";

	QFile headerFile(m_outDir + "/include/" + fileBaseName(name) + ".h");
	if (!headerFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
		std::cerr << QString("cannot create file: %1").arg(headerFile.fileName()).toLatin1().data() << std::endl;
		std::exit(-1);
	}
	QTextStream headerFileOut(&headerFile);

	// and the source file
	QFile classFile(m_outDir + "/src/" + fileBaseName(name) + ".cpp");
	if (!classFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
		std::cerr << QString("cannot create file: %1").arg(classFile.fileName()).toLatin1().data() << std::endl;
		std::exit(-1);
	}
	QTextStream classFileOut(&classFile);

	headerFileOut << writeHeaderDesc(className(name));
	headerFileOut << "#ifndef __" << name.toUpper() << "_H__\n";
	headerFileOut << "#define __" << name.toUpper() << "_H__\n\n";

	headerFileOut << "#include <QObject>\n";
	headerFileOut << "#include <QXmlStreamReader>\n";
	headerFileOut << "#include <QString>\n";
	headerFileOut << "#include <QDateTime>\n\n";
	if (m_namespace) {
		headerFileOut << "namespace " << nameSpaceName() << " {\n\n";
	}
	headerFileOut << "//! replace characters that are illigal in XML with their encodings\n";
	headerFileOut << "//!\n";
	headerFileOut << "//! \\return     QString\n";
	headerFileOut << "QString encode(const QString& str);\n\n"; // issue 19

	headerFileOut << "//! convert date time to string (faster than the QDateTime::toString)\n";
	headerFileOut << "//!\n";
	headerFileOut << "//! \\return     QString\n";
	headerFileOut << "QString dateToString( const QDateTime& dateTime );\n\n";

	headerFileOut << "//-----------------------------------------------------------\n";
	headerFileOut << "//! \\brief      Overload QXmlStreamReader to create a validation\n";
	headerFileOut << "//!             error and continue parsing (what raiseError does)\n";
	headerFileOut << "//!\n";
	headerFileOut << "class XmlStreamReader: public QObject,\n";
	headerFileOut << "                       public QXmlStreamReader\n{\n";
	headerFileOut << "Q_OBJECT\n\n";
	headerFileOut << "public:\n";
	headerFileOut << "    XmlStreamReader() : QXmlStreamReader() {}\n";
	headerFileOut << "    virtual ~XmlStreamReader() {}\n\n";
	headerFileOut << "    void validationError(const QString& errorStr);\n\n";
	headerFileOut << "signals:\n";
	headerFileOut << "    void signalValidationError(const QString& errorStr);\n";
	headerFileOut << "};\n";
	if (m_namespace) {
		headerFileOut << "} //end ns\n";
	}
	headerFileOut << "\n#endif\n";

	//classFileOut << "\n#include \"" << "../include/" << fileBaseName("Functions") << ".h\"\n\n";
//	classFileOut << "\n#include \"" << "../include/" << fileBaseName(name) << ".h\"\n\n";


	classFileOut << "#include \"" << fileBaseName(name) << ".h\"\n\n";
	if (m_namespace) {
		classFileOut << "namespace " << nameSpaceName() << " {\n\n";
	}
	classFileOut << "QString encode( const QString& str ) {\n\n";
	classFileOut << "    QString result( str );\n";
	classFileOut << "    const static QString  amp(\"&amp;\");\n";
	classFileOut << "    const static QString   lt(\"&lt;\");\n";
	classFileOut << "    const static QString   gt(\"&gt;\");\n";
	classFileOut << "    const static QString quot(\"&quot;\");\n";
	classFileOut << "    result.replace('&',  amp);\n";
	classFileOut << "    result.replace('<',  lt);\n";
	classFileOut << "    result.replace('>',  gt);\n";
	classFileOut << "    result.replace('\"', quot);\n";
	classFileOut << "    return result;\n";
	classFileOut << "}\n\n";

	classFileOut << "inline QString nrToString( int nr, int width ) {\n\n";
	classFileOut << "    if ( width == 2 && nr < 10 )\n";
	classFileOut << "        return QString::number( nr ).rightJustified( 2, '0' );\n";
	classFileOut << "    else if ( width == 3 && nr < 100 )\n";
	classFileOut << "        return QString::number( nr ).rightJustified( 3, '0' );\n";
	classFileOut << "    else\n";
	classFileOut << "        return QString::number( nr );\n";
	classFileOut << "}\n\n";

	classFileOut << "QString dateToString( const QDateTime& dateTime ) {\n\n";
	classFileOut << "    if ( !dateTime.isValid() ) return QString::null;\n\n";
	classFileOut << "    // make string yyyy-MM-ddTHH:mm:ss.zzzZ\n";
	classFileOut << "    QDateTime utcDateTime = dateTime.toUTC();\n";
	classFileOut << "    QString result( QString::number( utcDateTime.date().year() ) );\n";
	classFileOut << "    result += '-';\n    result += nrToString( utcDateTime.date().month(), 2 );\n";
	classFileOut << "    result += '-';\n    result += nrToString( utcDateTime.date().day(), 2 );\n";
	classFileOut << "    result += 'T';\n    result += nrToString( utcDateTime.time().hour(), 2 );\n";
	classFileOut << "    result += ':';\n    result += nrToString( utcDateTime.time().minute(), 2 );\n";
	classFileOut << "    result += ':';\n    result += nrToString( utcDateTime.time().second(), 2 );\n";
	classFileOut << "    result += '.';\n    result += nrToString( utcDateTime.time().msec(), 3 );\n";
	classFileOut << "    result += 'Z';\n    return result;\n";
	classFileOut << "}\n\n";

	classFileOut << "void XmlStreamReader::validationError(const QString& errorStr) {\n\n";
	classFileOut << "    QString error( errorStr );\n";
	classFileOut << "    error += \" at line \" + QString::number(lineNumber());\n";
	classFileOut << "    error += \" (column \" + QString::number(columnNumber());\n";
	classFileOut << "    error += \")\";\n";
	classFileOut << "    emit( signalValidationError( error ) );\n";
	classFileOut << "}\n";
	// round up
	if (m_namespace) {
		classFileOut << "\n} //end ns";
	}
	classFileOut << "\n";

	// close and flush
	headerFileOut.flush();
	headerFile.close();

	// close and flush
	classFileOut.flush();
	classFile.close();
}
