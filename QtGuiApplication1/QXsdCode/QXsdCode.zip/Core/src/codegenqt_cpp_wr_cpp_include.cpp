#include <cstdlib>
#include "codegenqt.h"

using namespace qXsd2Code;

void CodeGenQT::generateCpp_write_cpp_include(XSDObject *obj, QVector<QString> &IncludeList, QTextStream &classFileOut)
{
	QVector<XSDAttribute*>attributes = obj->attributes();
	QString name = obj->name();

	classFileOut << "#include <cstdlib>\n";  // for the occasional debug string
	classFileOut << "#include <iostream>\n"; // for the occasional debug string
	classFileOut << "#include \"" << nameSpaceName() + "_" + fileBaseName("Functions") << ".h\"\n";
	classFileOut << "\n#include \"" << fileBaseName(name) << ".h\"\n\n";
	// ������ �߰��ϴ°ɷ�..
	classFileOut << "#include <qmetaobject.h>\n";

//	for (int i = 0; i < IncludeList.size(); i++)
	//	classFileOut << "#include \"" << fileBaseName(IncludeList[i]) << ".h\"\n";

	////////////////////////////////////////////////
	//for (int j = 0; j < attributes.size(); j++)
	//{
	//	XSDAttribute *attr = attributes.at(j);
	//	if (knownType(attr->type()))
	//		continue;
	//	//if (!IncludeList.contains(attr->name()))
	//	if (!IncludeList.contains(attr->type()))
	//	{
	//		classFileOut << "#include \"" << fileBaseName(attr->name()) << ".h\"\n";
	//		IncludeList.append(attr->name());// insert()
	//	}
	//	else if (attr->isElement())
	//	{
	//		if (!IncludeList.contains(attr->name()))
	//		{
	//			classFileOut << "#include \"" << fileBaseName(attr->name()) << ".h\"\n";
	//			IncludeList.append(attr->name());// insert()
	//		}
	//	}
	//}

	if (m_namespace)
		classFileOut << "namespace " << nameSpaceName() << " {\n\n";

}
