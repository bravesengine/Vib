
#include <cstdlib>
#include "codegenqt.h"

using namespace qXsd2Code;
void CodeGenQT::generateCpp_DefaultConstructor(XSDObject *obj, QVector<QString> &IncludeList, QString nameSpace, QTextStream &classFileOut)
{
	QString name = obj->name();
	//QString upperName = name.toUpper();
	QVector<XSDAttribute*>attributes = obj->attributes();

	QVector<QString>enums = obj->enums();


	////////////////////////////////////////////////////////////////////////////////////////
	// constructor
	classFileOut << "// Constructor\n";
	classFileOut << className(name) << "::" << className(name) << "()";

	if (knownType(obj->baseClass()))
		classFileOut << attributeConstructor(attributes, "", "");
	else
		classFileOut << attributeConstructor(attributes, obj->baseClass(), "");

	classFileOut << "\n{\n}\n\n";

	if (enums.size() != 0)
	{
		classFileOut << "// Constructor\n";
		classFileOut << className(name) << "::" << className(name) << "(QString EnumStr)";

		classFileOut << attributeConstructor(attributes, obj->baseClass(), "");

		classFileOut << "\n{\n";
		classFileOut << "    QMetaEnum metaEnum = QMetaEnum::fromType<" << "e" + name << ">();\n";
		classFileOut << "    this->" << variableName(name) << " = " << "(e" + name + ")" << "metaEnum.keysToValue(EnumStr.toStdString().c_str());\n";
		//this->m_wigetType = (eWigetType)
		classFileOut << "}\n\n";
	}

	//WigetType(QString Enum);
	// constructor for parser function
	classFileOut << "// Constructor for parser function\n";
	classFileOut << className(name) << "::" << className(name) << "(XmlStreamReader& xml, QString CloseTag)" << ":\n" << className(name) << "()";

	if (obj->hasBaseClass() && !knownType(obj->baseClass()) )
	{
		QString val = "xml, \"" + obj->name() + "\"";			
		classFileOut << attributeConstructor(attributes, obj->baseClass(), val);
	}

	classFileOut << "\n{\n";

	bool first(true);
	for (int j = 0; j < attributes.size(); j++)
	{
		XSDAttribute *attr = attributes.at(j);
		// ���� �߰� (enum)
		if (attr->name().isEmpty())
			continue;

		if (!attr->isElement())
		{
			if (first)
			{
				classFileOut << "    QXmlStreamAttributes attr = xml.attributes();\n";
				first = false;
			}

			QString attrType = attr->type();
			QString type = localType(attrType); // convert to cpp types

			QString MethodName = methodName(attr->name());

			classFileOut << "    if ( attr.hasAttribute( \"" << attr->name() << "\" ) )\n";
			classFileOut << "    {\n";

			if (type == "QString") {

				classFileOut << "        if ( !set" << MethodName << "( attr.value( \"" << attr->name()
					<< "\" ).toString() ) )\n";

				//classFileOut << "        if ( !set" << attr->name() << "( attr.value( \"" << attr->name()
				//	<< "\" ).toString() ) )\n";
			}
			else if (type == "bool") {
				classFileOut << "        // booleans are sent as YES/NO, TRUE/FALSE or 1/0 textstrings \n";
				classFileOut << "        QString value = attr.value( \"" << attr->name() << "\" ).toString().toUpper();\n";
				classFileOut << "        if ( !set" << attr->name() << "( value == \"YES\" ||\n";
				classFileOut << "                             value == \"TRUE\" ||\n";
				classFileOut << "                             value == \"1\") )\n";
			}
			else if (type == "int")
			{			
				classFileOut << "        if ( !set" << MethodName << "( attr.value( \"" << attr->name()
					<< "\" ).toString().toInt() ) )\n";
			}
			else if (type == "QDateTime")
			{
				/* was removed with issue 80
				// timea may have a leading Z (issue 28)
				classFileOut << "                // date encoding should end on a Z, but some suppliers may exclude it\n";
				classFileOut << "                // we can be robust by checking for it\n";
				classFileOut << "                if (value.right(1) != \"Z\") { // new time encoding\n";
				classFileOut << "                     value.append(\"Z\");\n";
				classFileOut << "                }\n";
				*/
				//classFileOut << "        if ( !set" << attr->name() << "( ";
				classFileOut << "        if ( !set" << MethodName << "( ";
				classFileOut << dateFromString("attr.value( \"" + attr->name() + "\" ).toString()");
				classFileOut << ") )\n";
			}
			else if (type == "float") {

				classFileOut << "        if ( !set" << MethodName << "( attr.value( \"" << attr->name()
					<< "\" ).toString().replace(\",\", \".\").toFloat() ) )\n";
			}
			else if (type == "unsigned int")
			{
				classFileOut << "        if ( !set" << MethodName << "( attr.value( \"" << attr->name()
					<< "\" ).toString().toUInt() ) )\n";
			}
			else
			{
				//-- Simple Type ���� enum �ִ°��� Ȯ��. String ���� �޾Ƽ� ��ȯ
				//classFileOut << "        if ( !set" << attr->name() << "( attr.value( \"" << attr->name()
				//	<< "\" ).toString() ) )\n";
				classFileOut << "        if ( !set" << MethodName << "( attr.value( \"" << attr->name()
					<< "\" ).toString() ) )\n";
			}

			classFileOut << "            xml.validationError( \"error set " << MethodName << " = \" + attr.value( \""
				<< attr->name() << "\" ).toString() );\n";
			classFileOut << "    }\n";
		}
	}

	{
		if (obj->isSimpleElement() && obj->hasBaseClass() &&  knownType( obj->baseClass()) )
		{
			// ���� m_val�� Ÿ�Ժ��� ������ �ϸ��
			classFileOut << "	m_val =" << localTypeStringToFunction(obj->baseClass(), "xml.readElementText()") << ";\n}\n";

			//QString AA;
			//bool IsOK = true;
			//int VV = AA.toInt(&IsOK);
			//// ### Qt6: make inline except for the long long versions
			//short  toShort(bool *ok = nullptr, int base = 10) const;
			//ushort toUShort(bool *ok = nullptr, int base = 10) const;
			//int toInt(bool *ok = nullptr, int base = 10) const;
			//uint toUInt(bool *ok = nullptr, int base = 10) const;
			//long toLong(bool *ok = nullptr, int base = 10) const;
			//ulong toULong(bool *ok = nullptr, int base = 10) const;
			//qlonglong toLongLong(bool *ok = nullptr, int base = 10) const;
			//qulonglong toULongLong(bool *ok = nullptr, int base = 10) const;
			//float toFloat(bool *ok = nullptr) const;
			//double toDouble(bool *ok = nullptr) const;


			int xxx = 0;

			//classFileOut << "\n}\n";
		}
		else
		{
			classFileOut << "    bool stop(false);\n";
			classFileOut << "    while(!xml.atEnd() && !stop)\n    {\n";
			classFileOut << "        QXmlStreamReader::TokenType token = xml.readNext();\n";
			classFileOut << "        switch ( token )\n        {\n";
			classFileOut << "        case QXmlStreamReader::EndElement:\n";
			classFileOut << "            if (  xml.name() ==" << "CloseTag" << ")\n";
			//classFileOut << "            if (  xml.name() == \"" << name << "\" )\n";
			classFileOut << "                stop = true;\n";
			classFileOut << "            break;\n";

			bool StartElement(false);
			for (int j = 0; j < attributes.size(); j++)
			{
				XSDAttribute *attr = attributes.at(j);
				// ���� �߰� (enum)
				if (attr->name().isEmpty())
					continue;

				if (attr->isElement())
				{
					// ��?
					if (!StartElement)
					{
						classFileOut << "        case QXmlStreamReader::StartElement:\n";
						classFileOut << "            if ( xml.name() == \"" << attr->_name() << "\" )\n";
						StartElement = true;
					}
					else
					{
						classFileOut << "            else if ( xml.name() == \"" << attr->_name() << "\" )\n";
					}
					classFileOut << "            {\n";

					//if (attr->isSimpleElement())
					//{					
					//	localTypeToString(attr);
					//	classFileOut << "                " << localType(attr->type()) << " val = xml.readElementText();\n";
					//}
					//else
					//{
					classFileOut << "                " << attr->name() << " val( xml );\n";
					//}

					//classFileOut << "                " << attr->name() << " val( xml );\n";

					// className
					classFileOut << "                if ( xml.name() != \"" << attr->_name() << "\" )\n";
					classFileOut << "                    xml.raiseError( \"tag mismatch " << attr->_name() << "\" );\n";
					if (attr->isScalar())
					{
						classFileOut << "                else if ( !add" << attr->name() << "( val ) )\n";
						classFileOut << "                    xml.validationError( \"error add " << attr->name() << "\"  );\n";
					}
					else
					{
						classFileOut << "                else if ( !set" << attr->name() << "( val ) )\n";
						classFileOut << "                    xml.validationError( \"error set " << attr->name() << "\"  );\n";
					}
					classFileOut << "            }\n";
				}
			}

			if (StartElement)
			{
				classFileOut << "            else\n            {\n";
				classFileOut << "                xml.validationError( \"unexpected element \" + xml.name().toString() );\n";
				classFileOut << "            }\n";
				classFileOut << "            break;\n";
			}

			if (!obj->hasBaseClass())// && attributes.size() > 0)
			{
				classFileOut << "        default:\n";
				//classFileOut << "            xml.validationError( \"unexpected element in " << name << "\" );\n";
				classFileOut << "            break;\n";
				classFileOut << "        }\n";
				classFileOut << "    }\n}\n\n";
			}
			else //if (attributes.size() > 0)
			{
				classFileOut << "        }\n";
				classFileOut << "    }\n}\n\n";
			}
			//else
			//{
			//	classFileOut << "}\n\n";
			//}
		}
	}

	///////////////////////
	// copy constructor
	classFileOut << "// copy constructor\n";
	classFileOut << className(name) << "::" << className(name) << "(const " << className(name) << " &val)";

	if (obj->hasBaseClass() && !knownType(obj->baseClass()))
		classFileOut << "\n :  " << obj->baseClass() << "(val)";////QObject()";
	else if (knownType(obj->baseClass()))
		classFileOut << "\n :  m_val(val.m_val)";
	else
		classFileOut << "\n :  QObject()";
}
