/*
 *  codegenqt.cpp
 *
 *  schema2code is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  schema2code is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  Created by Lukassen on 11/06/08.
 *  Copyright 2010
 *
 */

#include <cstdlib>

#include "codegenqt.h"

using namespace qXsd2Code;

QString CodeGenQT::sizeEvaluatorForType(QString type, QString varName) {
	if (type == "xs:string")
		return varName + ".length()";
	else if (type == "xs:hexBinary") // or should it by a QByteArray?
		return varName + ".size()";
	else
		return varName;
}

QString CodeGenQT::localType(QString type) {
	if (type == "xs:string")
		return "QString";
	else if (type == "xs:hexBinary") // or should it by a QByteArray?
		return "QString";
	else if (type == "xs:boolean")
		return "bool";
	else if (type == "xs:integer")
		return "int";
	else if (type == "xs:int")
		return "int";
	else if (type == "xs:dateTime")
		return "QDateTime";
	else if (type == "xs:unsignedInt") // �߰�
		return "unsigned int";
	else if (type == "unknown") {
		std::cout << "WARNING unknown type found:" << type.toLatin1().data() << ", defaulting to QString" << std::endl;
		return "QString";
	}
	else if (type == "xs:decimal") // float
		return "float";
	else if (type == "xs:float") // float
		return "float";
	else if (type == "xs:short")  // �߰�.
		return "short";
	else
		return className(type);
}

bool CodeGenQT::knownType(QString type) {
	if (type == "xs:string")
		return true;
	else if (type == "xs:hexBinary")
		return true;
	else if (type == "xs:boolean")
		return true;
	else if (type == "xs:integer")
		return true;
	else if (type == "xs:int")
		return true;
	else if (type == "xs:dateTime")
		return true;
	else if (type == "xs:unsignedInt") // �߰�
		return true;
	else if (type == "unknown")
		return true;
	else if (type == "xs:decimal") // float
		return true;
	else if (type == "xs:float") // float
		return true;
	else if (type == "xs:short")
		return true;
	else
		return false;
}

bool CodeGenQT::IsCustomType(XSDAttribute *attr)
{	
	if (m_CustomTypes.contains(attr->type()))
		return true;
	return false;
}

QString CodeGenQT::localTypeToString(XSDAttribute *attr, QString varName, bool encode) {

	QString type = localType(attr->type()); // convert to cpp types
	if (type == "QDateTime") {
		varName = dateToString(varName);
	}
	else if (type == "bool") {
		varName = "QString( " + varName + " ? \"true\" : \"false\" )";
	}
	else if (type == "float")
	{
		if (attr->hasDigits())
		{
			varName = "QString::number(" + varName + ", 'f', " + QString::number(attr->digits()) + ")";
		}
		else
		{
			varName = "QString::number( " + varName + ", 'f')";
		}
	}
	else if (type == "unsigned int")
	{
		varName = "QString::number( " + varName + " )";
	}
	else if (type != "QString")
	{
		if (attr->isElement() || IsCustomType(attr))
		{
			varName = varName + ".toString()";
		}
		else
		{
			varName = "QString::number( " + varName + " )";
		}
	}
	else if (encode) {
		varName = "encode (" + varName + ")"; // default to string, issue 19
	}
	return varName;
}



QString CodeGenQT::localTypeStringToFunction(QString base, QString varName)
{
	QString type = localType(base);

	if (type == "QDateTime")
	{
	//	//QString ss;
	//	//varName = "dataToString"	
	//	//varName = dateToString(varName);
	}
	else if (type == "bool")
	{
		varName = varName + ".toLower() == \"true\"";
	}
	else if (type == "float")
	{
		varName = varName + ".toFloat();";
	}
	else if (type == "unsigned int")
	{
	//	varName = ".toUInt();"
	}
	else if (type == "int")
	{
		varName = varName + ".toInt();";
	}

	return varName;
}

