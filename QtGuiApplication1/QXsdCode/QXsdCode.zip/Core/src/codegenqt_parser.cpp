#include <cstdlib>
#include "codegenqt.h"

using namespace qXsd2Code;
void CodeGenQT::parserFile() {

	//-----------------------------------------------------------------------------------------------
	// now generate the parser
	//-----------------------------------------------------------------------------------------------

	// open the header file
	QString name = nameSpaceName() + "_" + "Parser";

	QFile headerFile(m_outDir + "/include/" + fileBaseName(name) + ".h");
	if (!headerFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
		std::cerr << QString("cannot create file: %1").arg(headerFile.fileName()).toLatin1().data() << std::endl;
		std::exit(3);
	}
	QTextStream headerFileOut(&headerFile);

	// and the parser file
	QFile classFile(m_outDir + "/src/" + fileBaseName(name) + ".cpp");
	if (!classFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
		std::cerr << QString("cannot create file: %1").arg(classFile.fileName()).toLatin1().data() << std::endl;
		std::exit(3);
	}
	QTextStream classFileOut(&classFile);

	// generate the header
	headerFileOut << writeHeaderDesc(className(name));
	headerFileOut << "#ifndef __" << name.toUpper() << "_H__\n";
	headerFileOut << "#define __" << name.toUpper() << "_H__\n\n";

	// include dependend files
	for (int i = 0; i < m_objects.size(); i++) {
		XSDObject *obj = m_objects.at(i);
		if (!obj->isEmbedded() && (obj->name() != "Schema") && !obj->isSimpleElement()) {
			headerFileOut << "#include \"" << fileBaseName(obj->name()) << ".h\"\n";
		}
	}


	if (m_namespace) {
		headerFileOut << "\nnamespace " << nameSpaceName() << " {\n";
	}


	headerFileOut << "class XmlStreamReader;\n\n";

	headerFileOut << "\n//-----------------------------------------------------------\n";
	headerFileOut << "//! \\brief       Class definition of " << className(name) << "\n";
	headerFileOut << "//!\n";

	// define the class
	headerFileOut << "class " << className(name) << " : public QObject { \n";
	headerFileOut << "    Q_OBJECT\n\n";

	// public section
	headerFileOut << "public:\n";
	headerFileOut << "    //!constructor\n";
	headerFileOut << "    //!\n";
	headerFileOut << "    " << className(name) << "();\n";
	headerFileOut << "    //!the actual parse routine\n";
	headerFileOut << "    //!\n";

	//-- ���� �߰�
	headerFileOut << "    \n";
	headerFileOut << "    //!destructor \n";
	headerFileOut << "    //!\n";
	headerFileOut << "    " << "~" << className(name) << "();\n";
	headerFileOut << "    //!the actual parse routine\n";
	headerFileOut << "    //!\n";


	headerFileOut << "    bool parseXMLString(QString data, bool cont);\n";

	// define the signals
	headerFileOut << "\nsignals:\n";
	headerFileOut << "    //!signals fired by the parser when a new object has been parsed\n";
	headerFileOut << "    //!\n";
	for (int i = 0; i < m_objects.size(); i++) {
		XSDObject *obj = m_objects.at(i);
		if (!obj->isEmbedded() && (obj->name() != "Schema") && !obj->isSimpleElement()) {
			headerFileOut << "    void signal" << className(obj->name()) << "( const ";
			if (m_namespace) {
				headerFileOut << "" << nameSpaceName() << "::";
			}
			headerFileOut << className(obj->name()) << "& obj );\n";
		}
	}
	// issue 24
	headerFileOut << "    //!signals fired by the parser when a parser problem occured\n";
	headerFileOut << "    //!\n";
	headerFileOut << "    void signalError(const QString& errorStr);\n";
	headerFileOut << "    void signalWarning(const QString& errorStr);\n";

	// issue 69
	headerFileOut << "    void signalValidationError(const QString& errorStr);\n";

	// private section
	headerFileOut << "\nprivate:\n";
	headerFileOut << "    void parse();\n";
	headerFileOut << "    XmlStreamReader* m_xml;\n";

	// close the header
	headerFileOut << "\n};\n";
	if (m_namespace) {
		headerFileOut << "} //end ns\n";
	}

	headerFileOut << "\n#endif\n";

	// close and flush
	headerFileOut.flush();
	headerFile.close();

	// The class file
	classFileOut << "#include <QRegExp>\n";

	classFileOut << "\n#include \"" << nameSpaceName() + "_" + fileBaseName("Functions") << ".h\"\n\n";
	classFileOut << "\n#include \"" << fileBaseName(name) << ".h\"\n\n";

	if (m_namespace) {
		classFileOut << "namespace " << nameSpaceName() << " {\n\n";
	}
	// constructor
	classFileOut << "// Constructor\n";
	classFileOut << className(name) << "::" << className(name) << "() {\n\n";
	classFileOut << "    m_xml = new XmlStreamReader;\n";
	classFileOut << "    connect( m_xml, SIGNAL(signalValidationError(const QString&)),\n";
	classFileOut << "             this,  SIGNAL(signalValidationError(const QString&)) );\n";
	classFileOut << "}\n\n";

	// destructor
	//-- ���� �߰�
	classFileOut << "// Destructor\n";
	classFileOut << className(name) << "::~" << className(name) << "() {\n\n";
	classFileOut << "    if(m_xml != NULL)\n";
	classFileOut << "		delete m_xml;\n";
	classFileOut << "    m_xml = NULL;\n";
	classFileOut << "}\n\n";




	// the parseXMLString routine
	classFileOut << "// the actual parsing routine\n";
	classFileOut << "bool " << className(name) << "::parseXMLString(QString data, bool cont) { \n\n";
	classFileOut << "     // add the data to what was left over from a previous parse run\n";

	// count the number of messages
	QStringList closeTags, rootObjects;
	for (int i = 0; i < m_objects.size(); i++) {
		XSDObject *obj = m_objects.at(i);
		if ((!obj->isEmbedded()) && (obj->name() != "Schema")) {
			rootObjects.append(obj->name());
			closeTags.append("</" + obj->name() + ">");
		}
	}

	// Issue 40 start
	// build a regexp for the rootTags
	QString regExp;

	if (m_xmlCloseTag.isEmpty())
	{
		QString commonPrefix = longestCommonPrefix(rootObjects);
		if (commonPrefix.size() > 0) {
			regExp = "</" + commonPrefix + "([A-Za-z0-9]*)>";
		}
		else {
			regExp = closeTags.join("|");
		}
	}
	else
	{
		regExp = "</" + m_xmlCloseTag + ">";
	}

	// we search the buffer for any close tag that matches our regexp
	classFileOut << "    // search the buffer for the nearest closetag\n";
	classFileOut << "    int index = 0;\n";
	classFileOut << "    QRegExp rx( \"" + regExp + "\");\n";

	classFileOut << "    m_xml->addData( data );\n";
	classFileOut << "    if ( (index = rx.indexIn( data )) != -1 )\n";
	classFileOut << "    {\n";
	classFileOut << "        // end found in last part\n";
	classFileOut << "        QString residu( data );\n";
	classFileOut << "        do\n        {\n";
	classFileOut << "            parse();\n";
	classFileOut << "            m_xml->clear();\n\n";
	classFileOut << "            // add make residu\n";
	classFileOut << "            int len = index + rx.matchedLength();\n";
	classFileOut << "            residu = residu.right( residu.length() - len );\n";
	classFileOut << "            m_xml->addData( residu );\n\n";
	classFileOut << "            // loop until no end found in residu\n";
	classFileOut << "        } while ( (index = rx.indexIn( residu )) != -1 );\n";
	classFileOut << "    }\n\n";
	classFileOut << "    if (!cont) {\n";
	classFileOut << "        m_xml->clear();\n";
	classFileOut << "    }\n";

	classFileOut << "    return true;\n";
	classFileOut << "}\n\n"; // close method

	classFileOut << "QString composeMessage( const QXmlStreamReader& xml ) {\n";
	classFileOut << "    QString errorstr( xml.errorString() );\n";
	classFileOut << "    errorstr += \" at line \" + QString::number(xml.lineNumber());\n";
	classFileOut << "    errorstr += \" (column \" + QString::number(xml.columnNumber());\n";
	classFileOut << "    errorstr += \")\";\n";
	classFileOut << "    return errorstr;\n";
	classFileOut << "}\n\n";

	// main parser routine
	//BrSkin_Parser


	classFileOut << "void " << name << "::parse() {\n\n";

	classFileOut << "    bool stop( false );\n";
	classFileOut << "    while(!m_xml->atEnd() && !stop)\n";
	classFileOut << "    {\n";
	classFileOut << "        QXmlStreamReader::TokenType token = m_xml->readNext();\n";
	classFileOut << "        if ( token == QXmlStreamReader::StartElement )\n        {\n";

	bool element(false);
	for (int i = 0; i < m_objects.size(); i++) {
		XSDObject *obj = m_objects.at(i);
		if (!obj->isEmbedded() && (obj->name() != "Schema") && !obj->isSimpleElement()) {
			if (!element)
			{
				classFileOut << "            if( m_xml->name()==\"" << obj->name() << "\" )\n";
				element = true;
			}
			else
				classFileOut << "            else if( m_xml->name()==\"" << obj->name() << "\" )\n";

			classFileOut << "            {\n";
			classFileOut << "                " << className(obj->name()) << " obj( *m_xml );\n";
			classFileOut << "                if ( m_xml->name() != \"" << obj->name() << "\" )\n";
			classFileOut << "                    m_xml->raiseError( \"tag mismatch " << className(obj->name()) << "\" );\n";
			classFileOut << "                else\n";
			classFileOut << "                {\n";
			classFileOut << "                    emit signal" << className(obj->name()) << "( obj );\n";
			classFileOut << "                    stop = true;\n";
			classFileOut << "                }\n";
			classFileOut << "            }\n";
		}
	}
	classFileOut << "        }\n    }\n\n";
	classFileOut << "    if ( m_xml->hasError() )\n";
	classFileOut << "    {\n";
	classFileOut << "        switch ( m_xml->error() )\n";
	classFileOut << "        {\n";
	classFileOut << "        case QXmlStreamReader::CustomError:\n";
	classFileOut << "            emit( signalValidationError( composeMessage( *m_xml ) ) );\n";
	classFileOut << "            break;\n";
	classFileOut << "        case QXmlStreamReader::PrematureEndOfDocumentError:\n";
	classFileOut << "            emit( signalWarning( composeMessage( *m_xml ) ) );\n";
	classFileOut << "            break;\n";
	classFileOut << "        case QXmlStreamReader::NotWellFormedError:\n";
	classFileOut << "        case QXmlStreamReader::UnexpectedElementError:\n";
	classFileOut << "            emit( signalError( composeMessage( *m_xml ) ) );\n";
	classFileOut << "            break;\n";
	classFileOut << "        case QXmlStreamReader::NoError:\n";
	classFileOut << "            break;\n";
	classFileOut << "        }\n    }\n}\n\n";

	if (!element) {
		std::cout << "ERROR: No base element found" << std::endl;
	}
	// round up
	if (m_namespace) {
		classFileOut << "} //end ns\n";
	}

	// close and flush
	classFileOut.flush();
	classFile.close();
}
