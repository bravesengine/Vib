#include <cstdlib>
#include "codegenqt.h"

using namespace qXsd2Code;

void CodeGenQT::generatorCpp_Func_ToXml(XSDObject *obj, QVector<QString> &IncludeList, QString nameSpace, QTextStream &classFileOut)
{
	QString name = obj->name();
	//QString upperName = name.toUpper();
	QVector<XSDAttribute*>attributes = obj->attributes();

	// xml generator
	// if attribute name and type are the same it means it was data
	classFileOut << "// Get XML Representation\n";
	//headerFileOut << "    const QString& toXML(bool outputNamespace = true, " << "QString xmlTag=\"" << name << "\"" << ");\n\n";

	classFileOut << "const QString& " << className(name) << "::toXML(bool outputNamespace, " << "QString xmlTag, " << "bool bWriteTag" << " ) {\n\n";

	classFileOut << "    if ( m_changed ) {\n";
	classFileOut << "        const static QString endAttr( \"\\\"\" );\n";
	//classFileOut << "        QString xml = \"<" << name << "\";\n"; // append attributes
	//classFileOut << "        QString xml = \"<\"" << "+ xmlTag;" <<  "\n"; // append attributes
	//QString xml;
	//if (!bWriteTag)
	//	xml = "<" + xmlTag;
	classFileOut << "        QString xml(\"\");\n"; // append attributes
	classFileOut << "        if(bWriteTag) xml = \"<\"" << "+ xmlTag;" << "\n";
	classFileOut << "        if (outputNamespace)\n";
	classFileOut << "        {\n";
	classFileOut << "            xml.append(\" xmlns:xsi=\\\"http://www.w3.org/2001/XMLSchema-instance\\\"\");\n";
	classFileOut << "            xml.append(\" xmlns=\\\"" << nameSpace << "\\\"\");\n";
	classFileOut << "        }\n";

	//-- �߰�.
	if (obj->hasBaseClass() && !knownType(obj->baseClass()))
	{
		//		classFileOut << "        xml.append(__super::toString(\"\", \"\"));\n";
		classFileOut << "        xml.append(__super::toXML(false, \"\", false));\n";
	}

	// ����.
	if (attributes.size() != 0)
		classFileOut << "        QString dataMember;\n"; // append attributes

														 // for attributes
	bool hasDataMembers = false;
	for (int j = 0; j < attributes.size(); j++) {
		XSDAttribute *attr = attributes.at(j);

		// ���� �߰� (enum)
		if (attr->name().isEmpty())
			continue;

		// QString attrType = attr->type();
		/*
		if ((attrType != attr->name()) && attr->isElement()) {
		std::cout << "ERROR: item assumed to be attribute but is element: " << attr->name().toLatin1().data() << std::endl;
		}
		if ((attrType != attr->name()) && attr->isElement()) {
		std::cout << "ERROR unknown attr :" <<  attr->name().toLatin1().data() <<  " mistaken for attribute" << std::endl;
		}
		*/

		if (!attr->isElement()) {
			// non-qstring items (ints) may give problems, so convert them
			QString varName = localTypeToString(attr, variableName(attr->name()), attr->enumeration().empty() && !attr->isFixed());

			// check if the attribute exist
			if (!attr->required() || obj->isMerged())
			{
				// issue 21
				classFileOut << "            // check for presence of optional attribute\n";
				classFileOut << "            if ( has" << methodName(attr->name()) << "() ) {\n";
				classFileOut << "                xml.append(\" " << attr->name() << "=\\\"\" + " << varName << " + endAttr);\n        }\n";
			}
			else
			{


				classFileOut << "        // check for presence of required  attribute\n";
				classFileOut << "        if ( " << variableName(attr->name()) << "Present) {\n";

				classFileOut << "            xml.append(\" " << attr->name() << "=\\\"\" + " << varName << " + endAttr);\n";

				classFileOut << "        } else { // required attribute not present\n";
				classFileOut << "            m_lastError = \"" << attr->name() << " not set\";\n";
				classFileOut << "            m_store  = QString::null;\n";
				classFileOut << "            return m_store;\n";
				classFileOut << "        }\n";
			}
		}
		else
		{
			hasDataMembers = true;
		}
	}

	// check for data members
	if (hasDataMembers) {

		//classFileOut << "        xml.append(\">\\n\");\n"; // close the statement
		classFileOut << "        if(bWriteTag) xml.append(\">\\n\");\n";

		// for data members
		for (int j = 0; j < attributes.size(); j++) {
			XSDAttribute *attr = attributes.at(j);

			// ���� �߰� (enum)
			if (attr->name().isEmpty())
				continue;
			QString attrType = localType(attr->type());

			//if ((attrType != attr->name()) && attr->isElement()) {
			//	std::cout << "ERROR: item assumed to be attribute but is element: " << attr->name().toLatin1().data() << std::endl;
			//}

			if (attr->isElement()) {
				// check if the attribute exist
				if (attr->isScalar())
				{

					if (attr->hasMinOccurs()) { // issue 26
						classFileOut << "        if (" << variableName(attr->name()) << "s.count() < " << attr->minOccurs() << ") {\n";
						classFileOut << "            m_lastError = \"not enough " << attr->name() << " values\";\n";
						classFileOut << "            m_store  = QString::null;\n";
						classFileOut << "            return m_store;\n";
						classFileOut << "        }\n";
					}
					if (attr->hasMaxOccurs()) { // issue 26
						classFileOut << "        if (" << variableName(attr->name()) << "s.count() > " << attr->maxOccurs() << ") {\n";
						classFileOut << "            m_lastError = \"too much " << attr->name() << " values\";\n";
						classFileOut << "            m_store  = QString::null;\n";
						classFileOut << "            return m_store;\n";
						classFileOut << "        }\n";
					}
					classFileOut << "        // add all included data\n";
					classFileOut << "        for(int i=0; i < " << variableName(attr->name()) << "s.count(); i++ ) {\n";
					classFileOut << "            " << attrType << " attribute = " << variableName(attr->name()) << "s.at(i);\n";

					if (attr->isSimpleElement())
					{
						// non-qstring items (ints) may give problems, so convert them
//						QString varName = localTypeToString(attr, "attribute", attr->enumeration().empty() && !attr->isFixed());
						QString varName = localTypeToString(attr, "attribute", attr->enumeration().empty() && !attr->isFixed());



						//QString xmlStr = attribute.toXML(false, " DBInstances");

						//classFileOut << "            xml.append( \"<" << attr->name() << ">\" + " << varName << " +  \"</" << attr->name() << ">\" );\n";

						classFileOut << "            xml.append( attribute.toXML(false, \"" << attr->name() << "\"));\n";


					}
					else {
						classFileOut << "            dataMember = attribute.toXML(false);\n";
						classFileOut << "            if (dataMember != QString::null) {\n";
						classFileOut << "               xml.append( dataMember );\n";
						classFileOut << "            } else {\n";
						classFileOut << "                m_lastError = \"" << attr->name() << ":\" + attribute.lastError();\n";
						classFileOut << "                m_store  = QString::null;\n";
						classFileOut << "                return m_store;\n";
						classFileOut << "            }\n";
					}
					classFileOut << "        }\n";
				}
				else if (!attr->required() || obj->isMerged()) {
					classFileOut << "        // add optional data if available\n";
					classFileOut << "        if ( has" << methodName(attr->name()) << "() ) {\n";

					// ����.
					if (attr->isSimpleElement() && !attr->isElement())
					{
						classFileOut << "            xml.append( \"<" << attr->name() << ">\" );\n";
						classFileOut << "            xml.append( " << variableName(attr->name()) << " );\n";
						classFileOut << "            xml.append( \"</" << attr->name() << ">\\n\" );\n";
					}
					else
					{
						//						classFileOut << "            dataMember = " << variableName(attr->name()) << ".toXML(false);\n";
						classFileOut << "            dataMember = " << variableName(attr->name()) << ".toXML(false," << "\"" << attr->name() << "\"" << ");\n";


						classFileOut << "            if (dataMember != QString::null) {\n";
						classFileOut << "                xml.append( dataMember );\n";
						classFileOut << "            } else {\n";
						classFileOut << "                m_lastError = \"" << attr->name() << ":\" + " << variableName(attr->name()) << ".lastError();\n";
						classFileOut << "                m_store  = QString::null;\n";
						classFileOut << "                return m_store;\n";
						classFileOut << "            }\n";
					}
					classFileOut << "        }\n";
				}
				else
				{
					classFileOut << "        // check for presence of required data member\n";
					classFileOut << "        if ( " << variableName(attr->name()) << "Present) {\n";

					//classFileOut << "            dataMember = " << variableName(attr->name()) << ".toXML(false);\n";
					classFileOut << "            dataMember = " << variableName(attr->name()) << ".toXML(false," << "\"" << attr->name() << "\"" << ");\n";

					classFileOut << "            if (dataMember != QString::null) {\n";
					classFileOut << "                xml.append( dataMember );\n";
					classFileOut << "            } else {\n";
					classFileOut << "                m_lastError = \"" << attr->name() << ":\" + " << variableName(attr->name()) << ".lastError();\n";
					classFileOut << "                m_store  = QString::null;\n";
					classFileOut << "                return m_store;\n";
					classFileOut << "            }\n";
					classFileOut << "        } else {\n";
					classFileOut << "            m_lastError = \"" << attr->name() << " not set\";\n";
					classFileOut << "            m_store  = QString::null;\n";
					classFileOut << "            return m_store;\n";
					classFileOut << "        }\n";
				}
			}
		}

		///-- ����.
		//classFileOut << "        xml.append( \"</" << name << ">\\n\");\n"; // append attributes
		//xml.append("</" + xmlTag + ">\n");

		///
		classFileOut << "        xml.append( \"</\"" << " + xmlTag + " << "\">\\n\");\n"; // append attributes

	}
	else
	{
		//
		//classFileOut << "        xml.append(\"/>\\n\");\n"; // close the statement

		classFileOut << "        if(bWriteTag) xml.append(\"/>\\n\");\n";

	}

	// close up
	classFileOut << "        m_store = xml;\n";
	classFileOut << "        m_changed = false;\n    }\n";
	classFileOut << "    return m_store;\n";
	classFileOut << "}\n\n";

	//////////////////////////////
}
