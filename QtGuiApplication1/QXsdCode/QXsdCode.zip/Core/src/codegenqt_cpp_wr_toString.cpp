#include <cstdlib>
#include "codegenqt.h"

using namespace qXsd2Code;

void CodeGenQT::generatorCpp_Func_ToString(XSDObject *obj, QVector<QString> &IncludeList, QString nameSpace, QTextStream &classFileOut)
{

	QString name = obj->name();
	//QString upperName = name.toUpper();
	QVector<XSDAttribute*>attributes = obj->attributes();

	QVector<QString>enums = obj->enums();

	//////////////////////////////
	//////////////////////////////
	//// ToString();..

	if (attributes.size() == 0 && enums.size() != 0)
	{
		// string generator
		// if attribute name and type are the same it means it was data
		classFileOut << "// Get String Representation\n";
		classFileOut << "QString " << className(name) << "::toString() const{\n\n";
		classFileOut << "    QMetaEnum metaEnum = QMetaEnum::fromType<" << "e" + name << ">();\n";
		classFileOut << "    return metaEnum.valueToKey(" << variableName(name) << ");\n";
		classFileOut << "}\n\n";

	}
	else
	{
		// string generator
		// if attribute name and type are the same it means it was data
		classFileOut << "// Get String Representation\n";
		classFileOut << "QString " << className(name) << "::toString() const{\n\n";
		classFileOut << "    return toString(\"\");\n";
		classFileOut << "}\n\n";
	}


	classFileOut << "// Get String Representation with a lead\n";

	//QString xmlTag = "DBInstances"
	classFileOut << "QString " << className(name) << "::toString(QString lead, " << "QString xmlTag" << ") const{\n\n";

	classFileOut << "    const static QString endAttr( \"\\n\" );\n";

	//classFileOut << "    QString str = lead + \"" << name << "\\n\";\n"; // append attributes
	classFileOut << "    QString str = lead + xmlTag;\n"; // append attributes

		// for attributes
	for (int j = 0; j < attributes.size(); j++) {
		XSDAttribute *attr = attributes.at(j);

		// ���� �߰� (enum)
		if (attr->name().isEmpty())
			continue;
		QString attrType = attr->type();
		QString type = localType(attr->type()); // convert to cpp types
												//if ((attrType != attr->name()) && attr->isElement()) {
												//	std::cout << "ERROR: item assumed to be attribute but is element: " << attr->name().toLatin1().data() << std::endl;
												//}


		if (!attr->isElement())//  && knownType(type) )
		{
			// non-qstring items (ints) may give problems, so convert them
			QString varName = localTypeToString(attr, variableName(attr->name()), false);
			// check if the attribute exist
			if (!attr->required() || obj->isMerged()) {
				classFileOut << "    // check for presence of optional attribute\n";
				classFileOut << "    if ( has" << methodName(attr->name()) << "() ) {\n";
				classFileOut << "        str.append( lead + \"" << attr->name() << "=\" + " << varName << " + endAttr);\n    }\n";
			}
			else
			{
				classFileOut << "    str.append( lead + \"" << attr->name() << "=\" + " << varName << " + endAttr);\n";
			}
		}
	}


	// for data members
	for (int j = 0; j < attributes.size(); j++) {
		XSDAttribute *attr = attributes.at(j);

		// ���� �߰� (enum)

		if (attr->name().isEmpty())
			continue;
		QString attrType = localType(attr->type());

		//if ((attrType != attr->name()) && attr->isElement()) {
		//	std::cout << "ERROR: item assumed to be attribute but is element: " << attr->name().toLatin1().data() << std::endl;
		//}

		if (attr->isElement()) {

			// check if the attribute exist
			if (attr->isScalar()) {

				classFileOut << "    // add all included data\n";
				classFileOut << "    for(int i=0; i < " << variableName(attr->name()) << "s.count(); i++ ) {\n";
				classFileOut << "        " << attrType << " attribute = " << variableName(attr->name()) << "s.at(i);\n";

				if (attr->isSimpleElement()) {
					// non-qstring items (ints) may give problems, so convert them
					QString varName = localTypeToString(attr, "attribute", false);
					classFileOut << "        str.append( lead + \"    \" + " << varName << " );\n";
				}
				else
				{
					classFileOut << "        str.append( attribute.toString( lead + \"    \" ) );\n";
				}

				classFileOut << "    }\n";
			}
			else if (!attr->required() || obj->isMerged()) {

				classFileOut << "    // add all optional data if present\n";
				classFileOut << "    if ( has" << methodName(attr->name()) << "() ) {\n";

				if (attr->isSimpleElement())
				{
					classFileOut << "        str.append( lead + \" \" );\n";
					if (attr->isElement())
					{
						classFileOut << "        str.append( " << variableName(attr->name()) << ".toString()" << " );\n";
					}
					else
					{
						classFileOut << "        str.append( \"" << attr->name() << " = \" );\n";
						classFileOut << "        str.append( " << variableName(attr->name()) << " );\n";
						classFileOut << "        str.append( \"\\n\" );\n";
					}
				}
				else
				{
					classFileOut << "        str.append(" << " " << variableName(attr->name()) << ".toString(lead + \"    \") );\n";
				}
				classFileOut << "    }\n";
			}
			else {
				classFileOut << "    str.append(" << " " << variableName(attr->name()) << ".toString(lead + \"    \") );\n";
			}
		}
	}


	// close up
	classFileOut << "    return str;\n";
	classFileOut << "}\n\n";

	classFileOut << "const QString& " << className(name) << "::lastError() const {\n";
	classFileOut << "    return m_lastError;\n}\n\n";

	classFileOut << "const bool& " << className(name) << "::changed() const {\n";
	classFileOut << "    return m_changed;\n}\n\n";

	classFileOut << "const QString& " << className(name) << "::store() const {\n";
	classFileOut << "    return m_store;\n}\n\n";

	// round up
	if (m_namespace) {
		classFileOut << "\n} //end ns";
	}
	classFileOut << "\n";
}