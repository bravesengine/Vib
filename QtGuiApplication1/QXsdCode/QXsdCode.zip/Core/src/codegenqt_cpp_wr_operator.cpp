
#include <cstdlib>
#include "codegenqt.h"

using namespace qXsd2Code;
void CodeGenQT::generateCpp_Operator(XSDObject *obj, QVector<QString> &IncludeList, QString nameSpace, QTextStream &classFileOut)
{

	// get some vars we frequently use
	QString name = obj->name();
	QString upperName = name.toUpper();
	QVector<XSDAttribute*>attributes = obj->attributes();
	QVector<QString>enums = obj->enums();

	for (int j = 0; j < attributes.size(); j++)
	{
		XSDAttribute *attr = attributes.at(j);
		if (attr->name().isEmpty())
			continue;

		QString attrType = attr->type();
		QString type = localType(attrType); // convert to cpp types
		if (attr->isScalar()) { // there more then one
			classFileOut << ",\n    " << variableName(attr->name()) << "s( val." << variableName(attr->name()) << "s )";
		}
		else {
			classFileOut << ",\n    " << variableName(attr->name()) << "( val." << variableName(attr->name()) << " )";
			//if (!attr->required() || obj->isMerged()) { //issue 21
			classFileOut << ",\n    " << variableName(attr->name()) << "Present( val." << variableName(attr->name()) << "Present )";
			//}
		}
	}

	classFileOut << ",\n    m_lastError()";
	classFileOut << ",\n    m_changed(val.m_changed )";
	classFileOut << ",\n    m_store(val.m_store )";
	classFileOut << "\n{\n";

	//-- hasEnums �� �ٲ۴�.
	if (enums.size() != 0)
		classFileOut << "	" << variableName(name) << "=" << "val." << variableName(name) << ";\n";

	classFileOut << "\n}\n\n";
	// == operator
	classFileOut << "// compare\n";
	classFileOut << "bool " << className(name) << "::operator==(const " << className(name) << " &val) {\n\n";

	//if (this == &(val))
	//{
	//	return true;
	//}

	for (int j = 0; j < attributes.size(); j++) {
		XSDAttribute *attr = attributes.at(j);

		// ���� �߰� (enum)
		if (attr->name().isEmpty())
			continue;

		QString attrType = attr->type();
		QString type = localType(attr->type()); // convert to cpp types
		if (attr->isScalar()) { // there more then one
			classFileOut << "    if (!(" << variableName(attr->name()) << "s == val." << variableName(attr->name()) << "s)) return false;\n";
		}
		else {
			classFileOut << "    if (!(" << variableName(attr->name()) << "Present == val." << variableName(attr->name()) << "Present)) return false;\n";
			classFileOut << "    if (!(" << variableName(attr->name()) << " == val." << variableName(attr->name()) << ")) return false;\n";
		}
	}

	if (enums.size() != 0)
	{
		classFileOut << "	if(" << variableName(name) << "!=" << "val." << variableName(name) << ")\n";
		classFileOut << "		return false;\n\n";
	}

	classFileOut << "    return true;\n";
	classFileOut << "}\n\n";

	//=============================================== = operator
	classFileOut << "// assignement\n";
	classFileOut << className(name) << " & " << className(name) << "::operator=(const " << className(name) << " &val) {\n\n";

	if (obj->hasBaseClass() && !knownType(obj->baseClass()))
		classFileOut << "    " << "__super::operator =(val);\n";

	for (int j = 0; j < attributes.size(); j++)
	{
		XSDAttribute *attr = attributes.at(j);

		// ���� �߰� (enum)
		if (attr->name().isEmpty())
			continue;

		// �߰�

		QString attrType = attr->type();
		QString type = localType(attr->type()); // convert to cpp types
		if (attr->isScalar()) { // there more then one
			classFileOut << "    " << variableName(attr->name()) << "s = val." << variableName(attr->name()) << "s;\n";
		}
		else {
			//if (!attr->required() || obj->isMerged()) { // issue 21
			classFileOut << "    " << variableName(attr->name()) << "Present = val." << variableName(attr->name()) << "Present;\n";
			//}
			classFileOut << "    " << variableName(attr->name()) << " = val." << variableName(attr->name()) << ";\n";
		}
	}

	if (enums.size() != 0)
	{
		classFileOut << "		" << variableName(name) << "=" << "val." << variableName(name) << ";\n";
	}

	if (obj->isSimpleElement())
	{
		classFileOut << "    m_val = val.m_val;\n";
	}

	classFileOut << "    m_changed = val.m_changed;\n";
	classFileOut << "    m_store = val.m_store;\n";
	classFileOut << "    return *this;\n";
	classFileOut << "}\n\n";


}