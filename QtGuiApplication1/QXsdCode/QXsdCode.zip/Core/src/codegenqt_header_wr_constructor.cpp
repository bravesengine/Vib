#include <cstdlib>
#include "codegenqt.h"

using namespace qXsd2Code;

void CodeGenQT::generate_Header(XSDObject *obj, QVector<QString> &IncludeList, QString nameSpace)
{
	//for (int i = 0; i < m_objects.size(); i++) {
	//	// get a class
	//	XSDObject *obj = m_objects.at(i);
	// get some vars we frequently use

	QString name = obj->name();
	QString upperName = name.toUpper();
	QVector<XSDAttribute*>attributes = obj->attributes();
	QMap<QString, QString>fixedValues = obj->fixedValues();

	QVector<QString>enums = obj->enums();

	//// check for simple elements
	//if (obj->isSimpleElement()) {
	//	std::cout << QString("skipping class: %1").arg(className(name)).toLatin1().data() << std::endl;
	//	return;
	//}

	// report
	std::cout << QString("creating : %1.h").arg(className(name)).toLatin1().data() << std::endl;

	// open the header file
	QFile headerFile(m_outDir + "/include/" + fileBaseName(name) + ".h");
	if (!headerFile.open(QIODevice::WriteOnly | QIODevice::Text))
	{
		std::cerr << QString("cannot create file: %1").arg(headerFile.fileName()).toLatin1().data() << std::endl;
		std::exit(3);
	}

	QTextStream headerFileOut(&headerFile);
	//-----------------------------------------------------------------------------------------------
	// generate the header
	//-----------------------------------------------------------------------------------------------

	headerFileOut << writeHeaderDesc(className(name));


	headerFileOut << "#ifndef __" << upperName << "_H__\n";
	headerFileOut << "#define __" << upperName << "_H__\n\n";
	headerFileOut << "#include <QObject>\n";
	headerFileOut << "#include <QString>\n";
	headerFileOut << "#include <QDateTime>\n";

	//if (obj->hasBaseClass())
	//	headerFileOut << "#include \"" << fileBaseName(obj->baseClass()) << ".h\"\n";

	//	// �⺻Ŭ������ ������ ������ �̹� �˰� �ִ� �⺻ ������� �ƴ϶�� ����
	//if (obj->hasBaseClass() && !knownType(obj->baseClass()))
	//	headerFileOut << "\nclass " << fileBaseName(obj->baseClass()) << "\n";

	//for (int j = 0; j < attributes.size(); j++)
	//{
	//	XSDAttribute *attr = attributes.at(j);
	//	if (attr->isElement())
	//		headerFileOut << "\nclass " << fileBaseName(attr->name()) << ";";
	//}

	// �⺻Ŭ������ ������ ������ �̹� �˰� �ִ� �⺻ ������� �ƴ϶�� ����
	if (obj->hasBaseClass() && !knownType(obj->baseClass()))
		headerFileOut << "#include \"" << fileBaseName(obj->baseClass()) << ".h\"\n";

	for (int j = 0; j < attributes.size(); j++)
	{
		XSDAttribute *attr = attributes.at(j);
		if (attr->isElement())
			headerFileOut << "#include \"" << fileBaseName(attr->name()) << ".h\"\n";//; ";
	}


	for (int j = 0; j < attributes.size(); j++)
	{
		XSDAttribute *attr = attributes.at(j);
		bool IsKnwontype = knownType(attr->type());
		bool IsContains = IncludeList.contains(attr->type());
		if (!IsKnwontype && !IsContains || attr->isElement() && !IsContains)
		{
			//headerFileOut << "#include \"" << fileBaseName(attr->type()) << ".h\"\n";
			if (attr->isElement())
				IncludeList.append(attr->name());
			else
				IncludeList.append(attr->type());
			if (IsAttrTypeHasObject(attr) && !IncludeList.contains(attr->name()))
				IncludeList.append(attr->name());
		}
	}

	if (m_namespace)
		headerFileOut << "\nnamespace " << nameSpaceName() << " {\n";



	headerFileOut << "\nclass XmlStreamReader;\n";

	QString docu = obj->docu();
	if (docu != "") { // there is documentation
		docu.replace("\n", "\\n\n//! ");
		docu.replace("\r", "");
	}

	headerFileOut << "\n//-----------------------------------------------------------\n";
	headerFileOut << "//! \\brief       Class definition of " << className(name) << "\n";
	headerFileOut << "//!\n";
	headerFileOut << "//! " << docu << "\n";
	headerFileOut << "//!\n";

	
	// define the class
	QString baseClass = "QObject";
	if (obj->hasBaseClass() && !knownType(obj->baseClass()))
		baseClass = obj->baseClass();


	headerFileOut << "class " << className(name) << " : public " << baseClass << " { \n";
	headerFileOut << "    Q_OBJECT\n\n";

	//-- has only enum...  ���� Ȯ��
	if (enums.size() != 0)
	{
		// public section
		headerFileOut << "public:\n";
		headerFileOut << "    //! enums\n";
		headerFileOut << "    //!\n";
		headerFileOut << "    " << "enum e" << name << "{\n";
		for (int i = 0; i < enums.size(); i++)
			headerFileOut << "        " << enums[i] << ",\n";

		headerFileOut << "    " << "     };" << "\n";
		headerFileOut << "    " << "Q_ENUM(" << "e" + name + ")\n";
		//Q_ENUM(eWigetType)
	}

	// public section
	headerFileOut << "public:\n";
	headerFileOut << "    //! constructor\n";
	headerFileOut << "    //!\n";
	headerFileOut << "    " << className(name) << "();\n";

	if (enums.size() != 0)
	{
		headerFileOut << "    //! constructor\n";
		headerFileOut << "    //!\n";
		headerFileOut << "    " << className(name) << "(QString EnumStr);\n";
	}

	headerFileOut << "    //! constructor for parser function\n";
	headerFileOut << "    //!\n";

	// ����
//	headerFileOut << "    " << className(name) << "(XmlStreamReader&, QString CloseTag =" << "\"" << className(name) << "\");\n";

	headerFileOut << "    " << className(name) << "(XmlStreamReader&, QString CloseTag =" << "\"" << name << "\");\n";


	headerFileOut << "    //! copy constructor\n";
	headerFileOut << "    //!\n";
	headerFileOut << "    " << className(name) << "(const " << className(name) << "&);\n";

	if (obj->hasBaseClass() && knownType(obj->baseClass()))
	{
		// �˰� �ִ� ������ �߰�.
		headerFileOut << "    " << className(name) << "(" << localType(obj->baseClass()) <<  " val"  << ")\n";
		headerFileOut << "	{\n" << "		m_val = val;\n" << "	}\n";
	}

	headerFileOut << "    //! = operator\n";
	headerFileOut << "    //!\n";
	headerFileOut << "    " << className(name) << " & operator=(const " << className(name) << "& val);\n"; // = operator

	headerFileOut << "    //! == operator\n";
	headerFileOut << "    //!\n";
	headerFileOut << "    bool operator==(const " << className(name) << "& val);\n"; // = operator																					 ////////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	//
	//
	///////////////////////////////////////////////////////////////////////////////////////////////////
	// all attributes																				

	for (int j = 0; j < attributes.size(); j++) {
		XSDAttribute *attr = attributes.at(j);

		// ���� �߰� (enum)
		if (attr->name().isEmpty())
			continue;

		//		QString type = localType(attr->type()); // convert to cpp types

		QString type;
		if (attr->isElement())
			type = attr->name();
		else
			type = localType(attr->type());

		QString doc = attr->doc();

		if (doc != "")
		{ // there is documentation
			doc.replace("\n", "\\n\n    //! ");
			doc.replace("\r", "");
		}

		if (attr->isScalar())
		{
			// there more then one
			// issue 72 delete

			headerFileOut << "    //! removes a " << methodName(attr->name()) << ".\n";
			headerFileOut << "    //!\n";

			if (attr->isElement())
				headerFileOut << "    bool remove" << methodName(attr->name()) << "(const " << type << "& val);\n\n";
			else
				headerFileOut << "    bool remove" << methodName(attr->name()) << "(" << type << " val);\n\n";

			// setter
			headerFileOut << "    //! adds a " << methodName(attr->name()) << ".\n";
			headerFileOut << "    //!\n";
			if (attr->isElement())
				headerFileOut << "    bool add" << methodName(attr->name()) << "(const " << type << "& val);\n\n";
			else
				headerFileOut << "    bool add" << methodName(attr->name()) << "(" << type << " val);\n\n";

			// getter
			headerFileOut << "    //! gets the i-th " << methodName(attr->name()) << ".\n";
			headerFileOut << "    //!\n";
			if (attr->isElement())
				headerFileOut << "    const " << type << "& get" << methodName(attr->name()) << "At(int i) const;\n\n";
			else
				headerFileOut << "    " << type << " get" << methodName(attr->name()) << "At(int i) const;\n\n";

			// count
			headerFileOut << "    //!              return the number of " << methodName(attr->name()) << " objects.\n";
			headerFileOut << "    //!\n";
			headerFileOut << "    //! \\return     int\n";
			headerFileOut << "    int countOf" << methodName(attr->name()) << "s() const;\n\n";
		}
		else {

			// setter
			if (doc != "")
				headerFileOut << "    //! sets the " << methodName(attr->name()) << ": " << doc << "\n";
			else
				headerFileOut << "    //! sets the " << methodName(attr->name()) << "\n";
			headerFileOut << "    //!\n";
			if (attr->isElement())
				headerFileOut << "    bool set" << methodName(attr->name()) << "(const " << type << "& val);\n\n";
			else
				headerFileOut << "    bool set" << methodName(attr->name()) << "(" << type << " val);\n\n";

			// getter
			if (doc != "")
				headerFileOut << "    //! gets the " << methodName(attr->name()) << ": " << doc << "\n";
			else
				headerFileOut << "    //! gets the " << methodName(attr->name()) << "\n";
			headerFileOut << "    //!\n";
			headerFileOut << "    //! \\return     " << type << "\n";
			headerFileOut << "    //!\n";
			if (attr->isElement())
				headerFileOut << "    const " << type << "& get" << methodName(attr->name()) << "() const;\n\n";
			else
				headerFileOut << "    " << type << " get" << methodName(attr->name()) << "() const;\n\n";
			if (!attr->required() || obj->isMerged())
			{
				headerFileOut << "    //! returns true if " << methodName(attr->name()) << "is used (optional field).\n";
				headerFileOut << "    //!\n";
				headerFileOut << "    //! \\return     bool\n";
				headerFileOut << "    bool has" << methodName(attr->name()) << "() const;\n\n";
			}
		}
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////////


	// and fixed values
	for (int j = 0; j < fixedValues.size(); j++) {
		QString attrName = fixedValues.keys().at(j);
		QString type = "QString"; // always a string

		// getter
		headerFileOut << "    //! gets the " << methodName(attrName) << "\n";
		headerFileOut << "    //!\n";
		headerFileOut << "    //! \\return     " << type << "\n";
		headerFileOut << "    //!\n";
		headerFileOut << "    " << type << " get" << methodName(attrName) << "() const;\n";
	}

	headerFileOut << "    //! generates XML of this object including attributes and child elements\n";
	headerFileOut << "    //! returns QString::null if not all required elements are available\n";
	headerFileOut << "    //! If null returned check lastError() for problem description\n";
	headerFileOut << "    //!\n";
	headerFileOut << "    //! \\return     QString\n";

	//headerFileOut << "    QString toString(QString lead, " << "QString xmlTag=\"" << name << "\"" << ") const;\n\n";

	headerFileOut << "    const QString& toXML(bool outputNamespace = true, " << "QString xmlTag=\"" << name << "\"" << ", bool bWriteTag=true" << ");\n\n";

	headerFileOut << "    //! generates output of this object including attributes and child elements\n";
	headerFileOut << "    //!\n";
	headerFileOut << "    //! \\return     QString\n";
	headerFileOut << "    QString toString() const;\n\n";

	headerFileOut << "    //! generates output of this object including attributes and child elements\n";
	headerFileOut << "    //!\n";
	headerFileOut << "    //! \\return     QString\n";


	//<< "QString =\" " << name << "\"" << ");\n\n";

	headerFileOut << "    QString toString(QString lead, " << "QString xmlTag=\"" << name << "\"" << ") const;\n\n";

	headerFileOut << "    //! return last error found in toXML function\n";
	headerFileOut << "    //!\n";
	headerFileOut << "    //! \\return     QString\n";
	headerFileOut << "    const QString& lastError() const;\n\n";

	headerFileOut << "    //! return changed \n";
	headerFileOut << "    //!\n";
	headerFileOut << "    //! \\return     bool\n";
	headerFileOut << "    const bool& changed() const;\n\n";

	headerFileOut << "    //! return store \n";
	headerFileOut << "    //!\n";
	headerFileOut << "    //! \\return     QString\n";
	headerFileOut << "    const QString& store() const;\n\n";


	if (enums.size() != 0)
	{
		headerFileOut << "	e" << name << " value() {\n" << "		return " << variableName(name) << ";\n	}\n";
	}




	///////////////////////////////////////////////////////////////////////////

	// private section
	headerFileOut << "\nprivate:\n";

	if (enums.size() != 0)
	{
		headerFileOut << "    " << "e" << name << " " << variableName(name) << ";\n";
	}


	// base�� �ְ� �˰� �ִ� Ÿ���ϰ�� �ش� Ÿ�� ���� ����
	if (obj->hasBaseClass() && knownType(obj->baseClass()))
	{
		headerFileOut << "    " << localType(obj->baseClass()) << " m_val;\n";
	}

	// all attributes
	for (int j = 0; j < attributes.size(); j++)
	{
		XSDAttribute *attr = attributes.at(j);

		// ���� �߰� (enum)
		if (attr->name().isEmpty())
			continue;

		QString type;
		if (attr->isElement())
			type = attr->name();
		else
			type = localType(attr->type()); // convert to cpp types
												// definition
		if (attr->isScalar())
		{ // there more then one
			headerFileOut << "    QList<" << type << "> " << variableName(attr->name()) << "s;\n";
		}
		else
		{
			headerFileOut << "    " << type << " " << variableName(attr->name()) << ";\n";
			//if (!attr->required() || obj->isMerged()) { // issue 21
			headerFileOut << "    bool " << variableName(attr->name()) << "Present;\n";
			//}
		}
	}

	// private section
	headerFileOut << "\npublic:\n";
	// all attributes
	for (int j = 0; j < attributes.size(); j++) {
		XSDAttribute *attr = attributes.at(j);

		// ���� �߰� (enum)
		if (attr->name().isEmpty())
			continue;

		if (!attr->isScalar())
		{
			if (!attr->required() || obj->isMerged()) {

				headerFileOut << "	void Set" << attr->name() << "Present(bool bPresent) {\n";
				headerFileOut << "		" << variableName(attr->name()) << "Present = bPresent;\n	}\n";
			}
		}
	}


	headerFileOut << "\nprivate:\n";
	// close the header
	headerFileOut << "    QString m_lastError; \n";
	headerFileOut << "    bool m_changed; \n";
	headerFileOut << "    QString m_store;\n";

	headerFileOut << "\npublic:\n";
	headerFileOut << "    void change(bool bChange) { m_changed =  bChange;}\n\n";
	headerFileOut << "}; \n";



	if (m_namespace) {
		headerFileOut << "} //end ns\n";
	}
	headerFileOut << "\n#endif\n";

	// close and flush
	headerFileOut.flush();
	headerFile.close();
	//}
}