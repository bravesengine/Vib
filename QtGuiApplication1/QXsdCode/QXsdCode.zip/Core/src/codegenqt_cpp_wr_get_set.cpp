#include <cstdlib>
#include "codegenqt.h"

using namespace qXsd2Code;

void CodeGenQT::generatorCpp_Get_Set(XSDObject *obj, QVector<QString> &IncludeList, QString nameSpace, QTextStream &classFileOut)
{
	//////////////////////////////////////////
	QVector<XSDAttribute*>attributes = obj->attributes();
	QString name = obj->name();
	// get set..  
	// methods for attributes

	for (int j = 0; j < attributes.size(); j++) {
		XSDAttribute *attr = attributes.at(j);

		// ���� �߰� (enum)
		if (attr->name().isEmpty())
			continue;

		QString attrType = attr->type();
		
		QString type;
		if (attr->isElement())
			type = attr->name();
		else
		   type = localType(attr->type()); // convert to cpp types

		if (attr->isScalar()) { // there more then one
								// deleter issue 70
			classFileOut << "// remover for " << className(name) << "\n";
			if (attr->isElement())
				classFileOut << "bool " << className(name) << "::remove" << methodName(attr->name()) << "(const " << type << "& val) {\n\n";
			else
				classFileOut << "bool " << className(name) << "::remove" << methodName(attr->name()) << "(" << type << " val) {\n\n";

			if (attr->hasMinOccurs()) {
				classFileOut << "    if (" << variableName(attr->name()) << "s.count() <= " << attr->minOccurs() << ") {\n";
				classFileOut << "        return false; // scalar already at minOccurs\n";
				classFileOut << "    }\n";
			}
			classFileOut << "    m_changed = true;\n";
			classFileOut << "    return " << variableName(attr->name()) << "s.removeOne(val);\n";
			classFileOut << "}\n\n";

			// setter
			classFileOut << "// setter for " << className(name) << "\n";
			if (attr->isElement())
				classFileOut << "bool " << className(name) << "::add" << methodName(attr->name()) << "(const " << type << "& val) {\n\n";
			else
				classFileOut << "bool " << className(name) << "::add" << methodName(attr->name()) << "(" << type << " val) {\n\n";

			if (attr->hasMaxOccurs()) { // issue 26
				classFileOut << "    if (" << variableName(attr->name()) << "s.count() >= " << attr->maxOccurs() << ") {\n";
				classFileOut << "        return false; // scalar already at maxOccurs\n";
				classFileOut << "    }\n";
			}
			if (attr->hasMinLength()) {
				QString evaluator = sizeEvaluatorForType(attr->type(), "val");

				classFileOut << "    if (" << evaluator << " < " << attr->minLength() << ") {\n        return false; // value is too small\n";
				classFileOut << "    }\n";
			}
			if (attr->hasMaxLength()) {
				QString evaluator = sizeEvaluatorForType(attr->type(), "val");

				classFileOut << "    if (" << evaluator << " > " << attr->maxLength() << ") {\n        return false; // value is too long\n";
				classFileOut << "    }\n";
			}

			classFileOut << "    " << variableName(attr->name()) << "s.append(val);\n";
			classFileOut << "    m_changed = true;\n";
			classFileOut << "    return true;\n";
			classFileOut << "}\n\n";

			// getter
			classFileOut << "// getter for " << className(name) << "\n";
			if (attr->isElement())
				classFileOut << "const " << type << "& " << className(name) << "::get" << methodName(attr->name()) << "At(int i) const {\n";
			else
				classFileOut << type << " " << className(name) << "::get" << methodName(attr->name()) << "At(int i) const {\n";


			classFileOut << "\n    return " << variableName(attr->name()) << "s.at(i);\n}\n\n";
			
			
			// count
			classFileOut << "// count for " << className(name) << "\n";
			classFileOut << "int " << className(name) << "::countOf" << methodName(attr->name()) << "s() const {\n";
			classFileOut << "\n    return " << variableName(attr->name()) << "s.count();\n}\n\n";
		}
		else {
			// setter
			classFileOut << "// setter for " << className(name) << "\n";
			if (attr->isElement())
				classFileOut << "bool " << className(name) << "::set" << methodName(attr->name()) << "(const " << type << "& val) {\n";
			else
				classFileOut << "bool " << className(name) << "::set" << methodName(attr->name()) << "(" << type << " val) {\n";
			QVector<QString> enums = attr->enumeration();
			if (enums.size() > 0) { // there are enumeration constraints for this item

									// strings should be between quotes, numbers not
				QString quote;
				if (type == "QString") {
					quote = "\"";
				}

				classFileOut << "\n    // check if the new value is an approved value";
				classFileOut << "\n    if ( ( val != " << quote << enums.at(0) << quote << " ) ";
				for (int h = 1; h < enums.size(); h++) {
					classFileOut << "&&\n         ( val != " << quote << enums.at(h) << quote << " ) ";
				}
				classFileOut << ")\n        return false;";
			}
			/////////////issue 72 start
			// check for strings too! you never have a min and a minLength!
			if (attr->hasMinLength() && knownType(attr->type())) {

				QString evaluator = sizeEvaluatorForType(attr->type(), "val");

				classFileOut << "\n    // check if the new value is within min length";
				classFileOut << "\n    if (" << evaluator << " < " << attr->minLength() << ")\n        return false;";
			}
			// check for strings too!
			if (attr->hasMaxLength() && knownType(attr->type())) {

				QString evaluator = sizeEvaluatorForType(attr->type(), "val");

				classFileOut << "\n    // check if the new value is within max length";
				classFileOut << "\n    if (" << evaluator << " > " << attr->maxLength() << ")\n        return false;";
			}
			/////////////issue 72 end
			if (attr->hasMinExclusive() && knownType(attr->type())) {

				QString evaluator = sizeEvaluatorForType(attr->type(), "val");

				classFileOut << "\n    // check if the new value is within min exclusive";
				classFileOut << "\n    if (" << evaluator << " <= " << attr->minExclusive() << ")\n        return false;";
			}
			if (attr->hasMaxExclusive() && knownType(attr->type())) {

				QString evaluator = sizeEvaluatorForType(attr->type(), "val");

				classFileOut << "\n    // check if the new value is within max exclusive";
				classFileOut << "\n    if (" << evaluator << " >= " << attr->maxExclusive() << ")\n        return false;";
			}
			if (attr->hasMinInclusive() && knownType(attr->type())) {

				QString evaluator = sizeEvaluatorForType(attr->type(), "val");

				classFileOut << "\n    // check if the new value is within min inclusive";
				classFileOut << "\n    if (" << evaluator << " < " << attr->minInclusive() << ")\n        return false;";
			}
			if (attr->hasMaxInclusive() && knownType(attr->type())) {

				QString evaluator = sizeEvaluatorForType(attr->type(), "val");

				classFileOut << "\n    // check if the new value is within max inclusive";
				classFileOut << "\n    if (" << evaluator << " > " << attr->maxInclusive() << ")\n        return false;";
			}
			//if (!attr->required() || obj->isMerged()) { // issue 21
			classFileOut << "\n    " << variableName(attr->name()) << "Present = true;";
			//}
			classFileOut << "\n    " << variableName(attr->name()) << " = val;\n";
			classFileOut << "    m_changed = true;\n";
			classFileOut << "    return true;\n";
			classFileOut << "}\n\n";

			// getter
			classFileOut << "// getter for " << className(name) << "\n";
			if (attr->isElement())
				classFileOut << "const " << type << "& " << className(name) << "::get" << methodName(attr->name()) << "() const {\n";
			else
				classFileOut << type << " " << className(name) << "::get" << methodName(attr->name()) << "() const {\n";


			//return *(&m_releasedate);

			if (attr->isElement())
				classFileOut << "\n    return  *(&" << variableName(attr->name()) << ");\n}\n\n";
			else
				classFileOut << "\n    return " << variableName(attr->name()) << ";\n}\n\n";



			if (!attr->required() || obj->isMerged()) { // issue 21 present only optional attributes on the interface
				classFileOut << "// check if optional element " << className(name) << " has been set\n";
				classFileOut << "bool " << className(name) << "::has" << methodName(attr->name()) << "() const {\n";
				classFileOut << "\n    return " << variableName(attr->name()) << "Present;\n}\n\n";
			}
		}
	}

	QMap<QString, QString>fixedValues = obj->fixedValues();
	// and fixed values
	for (int j = 0; j < fixedValues.size(); j++) {
		QString attrName = fixedValues.keys().at(j);
		QString attrValue = fixedValues.values().at(j);
		QString type = "QString"; // always a string

								  // getter
		classFileOut << "// getter for " << className(name) << "\n";
		classFileOut << type << " " << className(name) << "::get" << methodName(attrName) << "() const {\n";
		classFileOut << "\n    return \"" << attrValue << "\";\n}\n\n";
	}
}