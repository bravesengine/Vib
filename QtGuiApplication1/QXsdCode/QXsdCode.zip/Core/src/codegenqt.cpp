/*
 *  codegenqt.cpp
 *
 *  schema2code is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  schema2code is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  Created by Lukassen on 11/06/08.
 *  Copyright 2010
 *
 */

#include <cstdlib>

#include "codegenqt.h"

using namespace qXsd2Code;

CodeGenQT::CodeGenQT()
	: CodeGen(),
	m_prefix(),
	m_namespace(true)
{

}
//
//QString CodeGenQT::sizeEvaluatorForType(QString type, QString varName) {
//	if (type == "xs:string")
//		return varName + ".length()";
//	else if (type == "xs:hexBinary") // or should it by a QByteArray?
//		return varName + ".size()";
//	else
//		return varName;
//}
//
//QString CodeGenQT::localType(QString type) {
//	if (type == "xs:string")
//		return "QString";
//	else if (type == "xs:hexBinary") // or should it by a QByteArray?
//		return "QString";
//	else if (type == "xs:boolean")
//		return "bool";
//	else if (type == "xs:integer")
//		return "int";
//	else if (type == "xs:int")
//		return "int";
//	else if (type == "xs:dateTime")
//		return "QDateTime";
//	else if (type == "xs:unsignedInt") // �߰�
//		return "unsigned int";
//	else if (type == "unknown") {
//		std::cout << "WARNING unknown type found:" << type.toLatin1().data() << ", defaulting to QString" << std::endl;
//		return "QString";
//	}
//	else if (type == "xs:decimal") // float
//		return "float";
//	else if (type == "xs:float") // float
//		return "float";
//	else if (type == "xs:short")  // �߰�.
//		return "short";
//	else
//		return className(type);
//}
//
//bool CodeGenQT::knownType(QString type) {
//	if (type == "xs:string")
//		return true;
//	else if (type == "xs:hexBinary")
//		return true;
//	else if (type == "xs:boolean")
//		return true;
//	else if (type == "xs:integer")
//		return true;
//	else if (type == "xs:int")
//		return true;
//	else if (type == "xs:dateTime")
//		return true;
//	else if (type == "xs:unsignedInt") // �߰�
//		return true;
//	else if (type == "unknown")
//		return true;
//	else if (type == "xs:decimal") // float
//		return true;
//	else if (type == "xs:float") // float
//		return true;
//	else if (type == "xs:short")
//		return true;
//	else
//		return false;
//}
//
//bool CodeGenQT::IsCustomType(XSDAttribute *attr)
//{	
//	if (m_CustomTypes.contains(attr->type()))
//		return true;
//	return false;
//}
//
//QString CodeGenQT::localTypeToString(XSDAttribute *attr, QString varName, bool encode) {
//
//	QString type = localType(attr->type()); // convert to cpp types
//	if (type == "QDateTime") {
//		varName = dateToString(varName);
//	}
//	else if (type == "bool") {
//		varName = "QString( " + varName + " ? \"true\" : \"false\" )";
//	}
//	else if (type == "float") { // issue 63
//		if (attr->hasDigits()) {
//			varName = "QString::number(" + varName + ", 'f', " + QString::number(attr->digits()) + ")";
//		}
//		else {
//			varName = "QString::number( " + varName + ", 'f')";
//		}
//	}
//	else if (type == "unsigned int")
//	{
//		varName = "QString::number( " + varName + " )";
//	}
//	else if (type != "QString") {
//
//		//����
//		if (attr->isElement() || IsCustomType(attr))
//		{
//			varName = varName + ".toString()";
//		}
//		else
//		{
//			varName = "QString::number( " + varName + " )";
//		}
//	}
//	else if (encode) {
//		varName = "encode (" + varName + ")"; // default to string, issue 19
//	}
//	return varName;
//}

//-- attr�� �̸��� object�� ������ �ִ°�?
bool CodeGenQT::IsAttrTypeHasObject(XSDAttribute *attr)
{
	//headerFileOut << "#include \"" << fileBaseName(attr->name()) << ".h\"\n";
	//IncludeList.append(attr->name());// insert()
	if (!attr->isElement())
		return false;

	for (int i = 0; i < m_objects.size(); i++)
	{
		if (m_objects[i]->name() == attr->name())
			return true;
	}
	return false;
}


//////////////////////////////////////////////////////////////////////////////


QString CodeGenQT::longestCommonPrefix(QStringList strings) {

	if (strings.size() < 1) {
		return ""; // not good
	}
	if (strings.size() < 2) {
		return strings.at(0); // all in common with myself
	}
	// take the first item as initial prefix
	QString prefix = strings.at(0);
	int length = prefix.length();

	// compare the current prefix with the prefix of the same length of the other items
	foreach(QString item, strings) {
		// check if there is a match; if not, decrease the prefix by one character at a time
		while ((length > 0) && (item.left(length) != prefix)) {
			length--;
			prefix = prefix.left(length);
		}
	}

	// if no common prefix, return value will be ""
	return prefix;
}


void CodeGenQT::go() {

	QDir outDir(m_outDir);
	if (!outDir.exists())
	{
		std::cerr << QString("output dir does not exist: %1").arg(m_outDir).toLatin1().data() << std::endl;
		std::exit(1);
	}
	if (!outDir.exists("include") &&
		!outDir.mkdir("include"))
	{
		std::cerr << QString("can not create output dir: %1/include").arg(outDir.path()).toLatin1().data() << std::endl;
		std::exit(2);
	}
	if (!outDir.exists("src") &&
		!outDir.mkdir("src"))
	{
		std::cerr << QString("can not create output dir: %1/src").arg(outDir.path()).toLatin1().data() << std::endl;
		std::exit(2);
	}

	//m_CustomTypes �񸣱�?
	for (int i = 0; i < m_objects.size(); i++)
	{
		if (m_objects[i]->enums().size() != 0)
			m_CustomTypes.append(m_objects[i]->name());
	}

	functionsFile();
	classFiles();
	parserFile();

}

QString CodeGenQT::attributeConstructor(QVector<XSDAttribute*>& attributes, QString baseclass, QString ConstructVal)
{

	QString constructor;

	if (baseclass.isEmpty())
	{
		constructor += QString("\n :  QObject()");
	}
	else
	{
		//xs:integer(val),
		constructor += QString("\n :  " + baseclass + "(" + ConstructVal + ")");
	}

	for (int j = 0; j < attributes.size(); j++) {
		XSDAttribute *attr = attributes.at(j);

		QString type = localType(attr->type()); // convert to cpp types

		// ���� �߰� (enum)
		if (attr->name().isEmpty())
			continue;

		if (!attr->isScalar())
		{
			if (type == "QString")
			{
				if (attr->isFixed()) {
					constructor += ",\n    " + variableName(attr->name()) + "( \"" + attr->fixed() + "\" )";
					constructor += ", // initialize fixed value\n    " + variableName(attr->name()) + "Present( true )"; // issue 21
				}
				else {
					constructor += ",\n    " + variableName(attr->name()) + "()";
					constructor += ",\n    " + variableName(attr->name()) + "Present( false )"; // issue 21
				}
			}
			else {
				if (type == "bool") {
					constructor += ",\n    " + variableName(attr->name()) + "( false )";
				}
				else if (type == "int") {
					constructor += ",\n    " + variableName(attr->name()) + "( 0 )";
				}
				else if (type == "QDateTime") {
					constructor += ",\n    " + variableName(attr->name()) + "()";
				}
				else if (type == "float") {
					constructor += ",\n    " + variableName(attr->name()) + "( 0.0 )";
				}
				constructor += ",\n    " + variableName(attr->name()) + "Present( false )"; // issue 21
			}
		}
	}
	constructor += ",\n    m_changed(true)";
	return constructor;
}





void CodeGenQT::generate_Cpp(XSDObject *obj, QVector<QString> &IncludeList, QString nameSpace)
{
	// get some vars we frequently use
	QString name = obj->name();
	QString upperName = name.toUpper();
	QVector<XSDAttribute*>attributes = obj->attributes();
	QMap<QString, QString>fixedValues = obj->fixedValues();
	QVector<QString>enums = obj->enums();

	//// check for simple elements
	//if (obj->isSimpleElement()) {
	//	std::cout << QString("skipping class: %1").arg(className(name)).toLatin1().data() << std::endl;
	//	return;
	//}
	// report
	std::cout << QString("creating : %1.cpp").arg(className(name)).toLatin1().data() << std::endl;

	// and the class file
	QFile classFile(m_outDir + "/src/" + fileBaseName(name) + ".cpp");
	if (!classFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
		std::cerr << QString("cannot create file: %1").arg(classFile.fileName()).toLatin1().data() << std::endl;
		std::exit(3);
	}

	QTextStream classFileOut(&classFile);
	
	//-- #incldue write..
	generateCpp_write_cpp_include(obj, IncludeList, classFileOut);

	//-- write constructor..
	generateCpp_DefaultConstructor(obj, IncludeList, nameSpace, classFileOut);

	generateCpp_Operator(obj, IncludeList, nameSpace, classFileOut);



	generatorCpp_Get_Set(obj, IncludeList, nameSpace, classFileOut);

	generatorCpp_Func_ToXml(obj, IncludeList, nameSpace, classFileOut);
	generatorCpp_Func_ToString(obj, IncludeList, nameSpace, classFileOut);

	// close and flush
	classFileOut.flush();
	classFile.close();
	//}
}

void CodeGenQT::classFiles()
{
	// first analyse the objects if they are embedded objects
	// for all objects that could accept such an object
	QString nameSpace = "none";
	// bool useNameSpace = false;
	for (int i = 0; i < m_objects.size(); i++) {
		// for all objects
		XSDObject *obj1 = m_objects.at(i);
		obj1->setSimpleElement(false); // assume not a simple element

		// find if there is another object that refers to the obj
		for (int h = 0; h < m_objects.size(); h++) {

			XSDObject *obj2 = m_objects.at(h);
			// refers means obj2 has an attribute of type obj1
			for (int j = 0; j < obj2->attributes().size(); j++) {

				XSDAttribute *attr = obj2->attributes().at(j);
				QString objType = attr->type();

				// if obj1 is a simple element of obj2 we don't need to generate a class for it
				if (attr->isSimpleElement())
				{
					//std::cout << QString("Should i ignore attr: %1 for obj2 %2 obj1 %3?").arg(attr->name(), obj2->name(), obj1->name()).toLatin1().data() << std::endl;                    
					if (attr->type() != obj1->name() || !obj2->baseClass().isEmpty())
					{
						obj1->setSimpleElement(false);
						//						std::cout << QString("marking class: %1 for skip").arg(className(obj1->name())).toLatin1().data() << std::endl;
					}
					else
					{
						obj1->setSimpleElement(true);
						//-- �� �� �׳� ����..
						//std::cout << QString("marking class: %1 for skip").arg(className(obj1->name())).toLatin1().data() << std::endl;
					}
				}

				if (objType == obj1->name()) {
					obj1->setEmbedded();    // obj1 is embedded in obj2
				}
			}
		}

		// find out what our namespace is
		if (obj1->name() == "Schema") {
			for (int j = 0; j < obj1->fixedValues().size(); j++) {
				QString attrName = obj1->fixedValues().keys().at(j);
				if (attrName == "targetNamespace") {
					nameSpace = obj1->fixedValues().values().at(j);
					std::cout << "Using namespace: " << nameSpace.toLatin1().data() << std::endl;
					// useNameSpace = true;
				}
			}
		}


		for (int i = 0; i < m_objects.size(); i++) {
			// for all objects
			XSDObject *obj = m_objects.at(i);
			if (obj->hasBaseClass() && knownType(obj->baseClass()))
			{

				obj->setSimpleElement(true);
			}
		}
	}

	for (int i = 0; i < m_objects.size(); i++)
	{
		XSDObject *obj = m_objects.at(i);

		QVector<QString> IncludeList;

		generate_Header(obj, IncludeList, nameSpace);
		generate_Cpp(obj, IncludeList, nameSpace);

	}
}
