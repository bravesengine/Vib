#include <cstdlib>
#include "codegenqt.h"

using namespace qXsd2Code;

QString CodeGenQT::fileBaseName(QString name) {

	//return m_prefix + name.replace(0, 1, name.left(1).toUpper());
	return name.replace(0, 1, name.left(1).toUpper());
}

QString CodeGenQT::className(QString name) {
	return name.replace(0, 1, name.left(1).toUpper());
}

QString CodeGenQT::methodName(QString name) {
	return className(name);
}

QString CodeGenQT::variableName(QString name) {

	if (name.mid(1, 1).toUpper() == name.mid(1, 1)) { // if second char is uppercase
		return "m_" + name;
	}
	else {
		return "m_" + name.replace(0, 1, name.left(1).toLower());
	}
}