/*
 *  codegenqt.h
 *
 *  schema2code is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Foobar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  Created by Lukassen on 11/06/08.
 *  Copyright 2008
 *
 */

#ifndef __CODEGENQT_H__
#define __CODEGENQT_H__

#include <iostream>
#include <QtCore>

#include "codegen.h"


namespace qXsd2Code
{
	class XSDAttribute;
	class CodeGenQT : public QObject, public CodeGen {
		Q_OBJECT

	public:
		CodeGenQT();
		void setObjects(QVector<XSDObject*>objects)
		{
			m_objects = objects;
		}
		void setOutputDir(QString outDir)
		{
			m_outDir = outDir;
		}
		void setPrefix(QString prefix) { m_prefix = prefix; }
		void setNamespace(bool ns) { m_namespace = ns; }
		void setXmlCloseTag(QString xmlCloseTag) {
			m_xmlCloseTag = xmlCloseTag;
		}

		void go();

		static QString dateToString(QString varName) {

			return "dateToString( " + varName + ")";
		}

		static QString dateFromString(QString varName) {

			return "QDateTime::fromString(" + varName + ", Qt::ISODate)";
		}

	protected:
		bool knownType(QString type);

		bool IsAttrTypeHasObject(XSDAttribute *attr);



		QString sizeEvaluatorForType(QString type, QString varName);

		QString localType(QString type);
		QString localTypeToString(XSDAttribute *attr, QString varName, bool encode = true);
		QString localTypeStringToFunction(QString base, QString varName);

		QString nameSpaceName()
		{
			return m_prefix;// .toLower();
		}

		QString fileBaseName(QString name);
		QString className(QString name);
		QString variableName(QString name);
		
		QString writeHeaderDesc(QString fileName);

		QString methodName(QString name);
		QString longestCommonPrefix(QStringList);
		QString attributeConstructor(QVector<XSDAttribute*>& attributes, QString baseclass, QString ConstructVal);
		void classFiles();
		void parserFile();
		void functionsFile();

		bool IsCustomType(XSDAttribute *attr);

		void generate_Header(XSDObject *obj, QVector<QString> &IncludeList, QString nameSpace);

		//////////////
		void generateCpp_write_cpp_include(XSDObject *obj, QVector<QString> &IncludeList, QTextStream &classFileOut);

		void generate_Cpp(XSDObject *obj, QVector<QString> &IncludeList, QString nameSpace);

		void generateCpp_Operator(XSDObject *obj, QVector<QString> &IncludeList, QString nameSpace, QTextStream &classFileOut);	
		void generatorCpp_Get_Set(XSDObject *obj, QVector<QString> &IncludeList, QString nameSpace, QTextStream &classFileOut);		
		void generatorCpp_Func_ToXml(XSDObject *obj, QVector<QString> &IncludeList, QString nameSpace, QTextStream &classFileOut);
		void generatorCpp_Func_ToString(XSDObject *obj, QVector<QString> &IncludeList, QString nameSpace, QTextStream &classFileOut);
		void generateCpp_DefaultConstructor(XSDObject *obj, QVector<QString> &IncludeList, QString nameSpace, QTextStream &classFileOut);
		//////////////////////

	private:
		QString m_prefix;
		QString m_outDir;
		QString m_xmlCloseTag;
		bool    m_namespace;
		QVector<XSDObject*>m_objects;
		QVector<QString>m_CustomTypes;

	};
}
#endif
