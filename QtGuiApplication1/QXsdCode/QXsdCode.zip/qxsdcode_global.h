#pragma once

#include <QtCore/qglobal.h>

#ifndef BUILD_STATIC
# if defined(QXSDCODE_LIB)
#  define QXSDCODE_EXPORT Q_DECL_EXPORT
# else
#  define QXSDCODE_EXPORT Q_DECL_IMPORT
# endif
#else
# define QXSDCODE_EXPORT
#endif
